<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DictionarySynonym extends Model
{
    public $timestamps = false;
}