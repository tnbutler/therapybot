<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AnswerButton extends Model
{
    public $timestamps = false;
}