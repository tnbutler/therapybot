<?php

return [
    'no_rules_found' => 'No rules found.',
    'no_rules_applied_to_answer' => 'No rules applied to the answer.',
    'cant_find_dictionary_group' => 'Can\'t find dictionary group.',
];